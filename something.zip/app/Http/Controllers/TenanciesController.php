<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Tenant;
use App\Property;
use App\Tenancy;
use DB;

class TenanciesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tenancies = DB::table('tenancies')
            ->select('tenants.name AS tenant_name', 'properties.name AS property_name', 'start_date', 'end_date', 'rent')
            ->join('tenants', 'tenants.id', '=', 'tenancies.tenant_id')
            ->join('properties', 'properties.id', '=', 'tenancies.property_id')
            ->paginate(3);
        return view('tenancies.index',  compact("tenancies"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $properties = Property::all();
        $tenants = Tenant::all();
        $data = [
            'properties'=>$properties,
            'tenants' => $tenants
        ];
        return view('tenancies.create', compact("data"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'tenant_id'     => 'required',
            'property_id'  => 'required',
            'start_date' => 'required',
            'end_date' => 'required',
            'rent' => 'required'

        ]);

        $tenancy = new Tenancy;
        $tenancy->tenant_id = $request->input('tenant_id');
        $tenancy->property_id = $request->input('property_id');
        $tenancy->start_date = $request->input('start_date');
        $tenancy->end_date = $request->input('end_date');
        $tenancy->rent = $request->input('rent');
        $tenancy->save();

        return redirect('/tenancies');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
