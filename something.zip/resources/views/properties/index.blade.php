@extends('layouts.app')
@section('content')
    <div class="container">
        <table class="table">
            <tr>
                <th>Property image</th>
                <th>Property name</th>
                <th>Property address</th>
                <th>Property value</th>
                <th>Mortgage</th>
            </tr>
            @foreach($properties as $property)
            <tr>
                <td><img class="img" src="/storage/images/{{$property->photo}}"></td>
                <td>{{$property->name}}</td>
                <td>{{$property->address}}</td>
                <td>{{$property->val}}</td>
                <td>{{$property->mortgage}}</td>
            </tr>
            @endforeach
        </table>
        {{ $properties->links() }}

    </div>
@endsection
