@extends('layouts.app')
@section('content')
    <div class="container">
        <table class="table">
            <tr>
                <th>Tenant name</th>
                <th>Property</th>
                <th>Start date</th>
                <th>End date</th>
                <th>Monthly rate</th>
            </tr>
            @foreach($tenancies as $tenancy)
                <tr>
                    <td>{{$tenancy->tenant_name}}</td>
                    <td>{{$tenancy->property_name}}</td>
                    <td>{{$tenancy->start_date}}</td>
                    <td>{{$tenancy->end_date}}</td>
                    <td>{{$tenancy->rent}}</td>
                </tr>
            @endforeach

        </table>
        {{ $tenancies->links() }}

    </div>
@endsection