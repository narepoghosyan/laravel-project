@extends('layouts.app')
@section('content')
    <div class="container">
        <table class="table">
            <col width="30%">
            <col width="35%">
            <col width="35%">
            <tr>
                <th>Tenant image</th>
                <th>Tenant name</th>
                <th>Tenant address</th>
            </tr>
            @foreach($tenants as $tenant)
                <tr>
                    <td><img class="img" src="/storage/images/{{$tenant->photo}}"></td>
                    <td>{{$tenant->name}}</td>
                    <td>{{$tenant->address}}</td>
                </tr>
            @endforeach
        </table>
        {{ $tenants->links() }}
    </div>
@endsection
