
<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <tr>
                <th>Tenant name</th>
                <th>Property</th>
                <th>Start date</th>
                <th>End date</th>
                <th>Monthly rate</th>
            </tr>
            <?php $__currentLoopData = $tenancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tenancy->tenant_name); ?></td>
                    <td><?php echo e($tenancy->property_name); ?></td>
                    <td><?php echo e($tenancy->start_date); ?></td>
                    <td><?php echo e($tenancy->end_date); ?></td>
                    <td><?php echo e($tenancy->rent); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        <?php echo e($tenancies->links()); ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/something/resources/views/tenancies/index.blade.php ENDPATH**/ ?>