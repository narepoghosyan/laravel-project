
<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <col width="30%">
            <col width="35%">
            <col width="35%">
            <tr>
                <th>Tenant image</th>
                <th>Tenant name</th>
                <th>Tenant address</th>
            </tr>
            <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img class="img" src="/storage/images/<?php echo e($tenant->photo); ?>"></td>
                    <td><?php echo e($tenant->name); ?></td>
                    <td><?php echo e($tenant->address); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($tenants->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/something/resources/views/tenants/index.blade.php ENDPATH**/ ?>