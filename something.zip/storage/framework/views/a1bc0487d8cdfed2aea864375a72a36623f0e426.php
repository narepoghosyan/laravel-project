
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Create a property</h1>
        <form method="POST" action="/tenancies"  enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="tenant_id">Choose a tenant</label>
                <select name="tenant_id" id="tenant_id" class="form-control">
                    <?php $__currentLoopData = $data['tenants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tenant->id); ?>"><?php echo e($tenant->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="property_id">Choose a property</label>
                <select name="property_id" id="property_id" class="form-control">
                    <?php $__currentLoopData = $data['properties']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($property->id); ?>"><?php echo e($property->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="start_date">Start date</label>
               <input type="date" name="start_date" id="start_date" class="form-control">
            </div>
            <div class="form-group">
                <label for="end_date">End date</label>
                <input type="date" id="end_date" name="end_date" class="form-control">
            </div>
            <div class="form-group">
                <label for="rent">Monthly rate</label>
                <input type="text" id="rent" name="rent" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-4">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/something/resources/views/tenancies/create.blade.php ENDPATH**/ ?>