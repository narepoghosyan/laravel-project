
<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <tr>
                <th>Property image</th>
                <th>Property name</th>
                <th>Property address</th>
                <th>Property value</th>
                <th>Mortgage</th>
            </tr>
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><img class="img" src="/storage/images/<?php echo e($property->photo); ?>"></td>
                <td><?php echo e($property->name); ?></td>
                <td><?php echo e($property->address); ?></td>
                <td><?php echo e($property->val); ?></td>
                <td><?php echo e($property->mortgage); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($properties->links()); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/something/resources/views/properties/index.blade.php ENDPATH**/ ?>